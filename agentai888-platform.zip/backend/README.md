# Revvy Backend — AgentAI888 Revenue Agent

The service that powers the Revvy Revenue Agent inside the AgentAI888 affiliate
dashboard. One FastAPI app, four capabilities:

1. **AI proxy** — Revvy's chat, Blueprint, and prospectus generation run through
   here, so your Anthropic key stays on the server (never in the browser).
2. **Lead storage** — every Leak & Fix Blueprint auto-saves the prospect as a lead.
3. **Prospectus storage** — generated prospectuses save to the affiliate's account.
4. **Twilio voice + SMS** — Revvy can call or text a prospect from your number.

The dashboard works fine with **no backend** (Revvy runs in demo mode). The backend
turns on the live capabilities.

---

## 1 · Set up the database (Supabase)

1. Create a project at supabase.com (or use your existing one).
2. Open **SQL Editor ▸ New query**, paste the contents of `schema.sql`, and run it.
   This creates three tables: `revvy_leads`, `revvy_prospectuses`, `revvy_calls`.
3. From **Project Settings ▸ API**, copy the **Project URL** and the
   **service_role** key (the secret one — not the anon key).

## 2 · Deploy the backend (Railway, Render, or Fly.io)

Railway is the quickest:

1. Push this `revvy_backend` folder to a GitHub repo.
2. On railway.app: **New Project ▸ Deploy from GitHub repo**.
3. Railway auto-detects Python. Set the start command if needed:
   `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Under **Variables**, add everything from `.env.example` with real values.
   Set `PUBLIC_BASE_URL` to the URL Railway gives you (e.g.
   `https://revvy-backend.up.railway.app`).
5. Deploy. Visit the URL — you should see `{"service":"Revvy Backend","status":"online"}`.

Run locally instead:
```
pip install -r requirements.txt
cp .env.example .env          # fill in real values
uvicorn main:app --reload --port 8000
```

## 3 · Get a Twilio number (for voice + SMS)

1. Sign up at twilio.com, buy a phone number with Voice + SMS.
2. From the Twilio Console copy your **Account SID** and **Auth Token**.
3. Put them, plus the number (E.164 format, e.g. `+18325551234`), into the
   backend's environment variables.

## 4 · Connect the dashboard

1. Open the affiliate dashboard, click **⚙ Setup**.
2. In **3 · Revvy Backend**, paste your backend URL.
3. Save. Open the **Revvy — Revenue Agent** panel — the status line shows which
   capabilities are live (AI · Storage · Voice/SMS).

---

## Endpoints

| Method | Path                 | Purpose                                |
|--------|----------------------|----------------------------------------|
| GET    | `/`                  | Health check                           |
| GET    | `/api/status`        | Which capabilities are configured      |
| POST   | `/api/ai`            | AI completion (proxied to Anthropic)   |
| POST   | `/api/leads`         | Save a lead                            |
| GET    | `/api/leads`         | List an affiliate's leads              |
| POST   | `/api/prospectuses`  | Save a prospectus                      |
| GET    | `/api/prospectuses`  | List an affiliate's prospectuses       |
| POST   | `/api/sms`           | Send an SMS via Twilio                 |
| POST   | `/api/call`          | Place a voice call via Twilio          |
| GET    | `/api/twiml`         | Voice script Twilio fetches on a call  |

## Security notes

- The Anthropic key, Supabase service key, and Twilio token live **only** on the
  server. The browser never receives them.
- `ALLOWED_ORIGINS` should be set to your real site domain(s) in production
  instead of `*`.
- The backend uses Supabase's service-role key, which bypasses Row Level
  Security — so the tables stay locked to the public and only the backend writes.
- For real outbound calling at scale, review Twilio's compliance rules
  (consent, calling hours, opt-out handling).
