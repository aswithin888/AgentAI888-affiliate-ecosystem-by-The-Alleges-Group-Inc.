-- ════════════════════════════════════════════════════════════
-- Revvy Backend — Supabase schema
-- Run this in the Supabase SQL Editor (Dashboard ▸ SQL Editor ▸ New query)
-- ════════════════════════════════════════════════════════════

-- 1 · Leads captured by Revvy
create table if not exists revvy_leads (
  id             uuid primary key default gen_random_uuid(),
  affiliate_code text not null,
  business_name  text not null,
  industry       text default '',
  contact_name   text default '',
  phone          text default '',
  email          text default '',
  pain_point     text default '',
  blueprint      text default '',
  status         text default 'new',     -- new | contacted | demo_booked | won | lost
  source         text default 'revvy',
  created_at     timestamptz default now()
);
create index if not exists idx_revvy_leads_aff on revvy_leads (affiliate_code);

-- 2 · White-label prospectuses Revvy generates
create table if not exists revvy_prospectuses (
  id             uuid primary key default gen_random_uuid(),
  affiliate_code text not null,
  business_name  text not null,
  industry       text default '',
  contact_name   text default '',
  pain_point     text default '',
  content        text not null,
  created_at     timestamptz default now()
);
create index if not exists idx_revvy_prosp_aff on revvy_prospectuses (affiliate_code);

-- 3 · Voice + SMS activity log
create table if not exists revvy_calls (
  id             uuid primary key default gen_random_uuid(),
  affiliate_code text default '',
  direction      text default 'outbound', -- outbound | inbound
  channel        text default 'voice',    -- voice | sms
  to_number      text default '',
  body           text default '',
  status         text default '',         -- sent | initiated | completed | failed
  created_at     timestamptz default now()
);
create index if not exists idx_revvy_calls_aff on revvy_calls (affiliate_code);

-- ── Row Level Security ──
-- The backend uses the SERVICE ROLE key, which bypasses RLS, so these
-- tables are safe to leave with RLS enabled and no public policies.
-- The browser never touches these tables directly — only the backend does.
alter table revvy_leads        enable row level security;
alter table revvy_prospectuses enable row level security;
alter table revvy_calls        enable row level security;
