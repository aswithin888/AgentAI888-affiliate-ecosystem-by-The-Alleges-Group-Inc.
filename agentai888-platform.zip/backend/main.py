"""
Revvy Backend — AgentAI888 Revenue Agent service
The Alleges Group Inc.

One FastAPI service that wires up the Revvy Revenue Agent:
  1. AI proxy        — keeps the Anthropic key server-side (browser never sees it)
  2. Lead / prospectus storage — saves to Supabase
  3. Twilio voice + SMS — outbound calling and texting

Run locally:   uvicorn main:app --reload --port 8000
Deploy:        Railway / Render / Fly.io  (start command: uvicorn main:app --host 0.0.0.0 --port $PORT)
"""

import os
import json
import datetime
from typing import Optional, List

import httpx
from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from pydantic import BaseModel

# ────────────────────────────────────────────────────────────
# Configuration — all secrets come from environment variables
# ────────────────────────────────────────────────────────────
ANTHROPIC_API_KEY   = os.environ.get("ANTHROPIC_API_KEY", "")
ANTHROPIC_MODEL     = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-20250514")

SUPABASE_URL        = os.environ.get("SUPABASE_URL", "")
SUPABASE_SERVICE_KEY = os.environ.get("SUPABASE_SERVICE_KEY", "")  # service role key

TWILIO_ACCOUNT_SID  = os.environ.get("TWILIO_ACCOUNT_SID", "")
TWILIO_AUTH_TOKEN   = os.environ.get("TWILIO_AUTH_TOKEN", "")
TWILIO_FROM_NUMBER  = os.environ.get("TWILIO_FROM_NUMBER", "")  # e.g. +1832XXXXXXX

# Public base URL of THIS service (needed so Twilio can fetch call instructions)
PUBLIC_BASE_URL     = os.environ.get("PUBLIC_BASE_URL", "http://localhost:8000")

# Comma-separated list of allowed front-end origins, or * for any
ALLOWED_ORIGINS     = os.environ.get("ALLOWED_ORIGINS", "*")

app = FastAPI(title="Revvy Backend", version="1.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"] if ALLOWED_ORIGINS.strip() == "*" else
                  [o.strip() for o in ALLOWED_ORIGINS.split(",")],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ────────────────────────────────────────────────────────────
# Small helpers
# ────────────────────────────────────────────────────────────
def _now() -> str:
    return datetime.datetime.utcnow().isoformat()


async def _supabase(method: str, path: str, payload: Optional[dict] = None,
                     params: Optional[dict] = None) -> list:
    """Minimal Supabase REST client. Returns the parsed JSON list/dict."""
    if not (SUPABASE_URL and SUPABASE_SERVICE_KEY):
        raise HTTPException(503, "Supabase is not configured on the server.")
    url = f"{SUPABASE_URL}/rest/v1/{path}"
    headers = {
        "apikey": SUPABASE_SERVICE_KEY,
        "Authorization": f"Bearer {SUPABASE_SERVICE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "return=representation",
    }
    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.request(method, url, headers=headers,
                                  json=payload, params=params)
    if r.status_code >= 300:
        raise HTTPException(r.status_code, f"Supabase error: {r.text}")
    try:
        return r.json()
    except Exception:
        return []


# ────────────────────────────────────────────────────────────
# 1 · AI PROXY  — Revvy's brain, key stays server-side
# ────────────────────────────────────────────────────────────
class ChatMessage(BaseModel):
    role: str
    content: str


class AIRequest(BaseModel):
    messages: List[ChatMessage]
    system: Optional[str] = ""
    max_tokens: Optional[int] = 1000


@app.post("/api/ai")
async def ai_proxy(req: AIRequest):
    """Proxies a chat completion to Anthropic. The browser never sees the key."""
    if not ANTHROPIC_API_KEY:
        raise HTTPException(503, "ANTHROPIC_API_KEY is not set on the server.")
    body = {
        "model": ANTHROPIC_MODEL,
        "max_tokens": req.max_tokens or 1000,
        "messages": [m.dict() for m in req.messages],
    }
    if req.system:
        body["system"] = req.system
    headers = {
        "x-api-key": ANTHROPIC_API_KEY,
        "anthropic-version": "2023-06-01",
        "content-type": "application/json",
    }
    async with httpx.AsyncClient(timeout=60) as client:
        r = await client.post("https://api.anthropic.com/v1/messages",
                               headers=headers, json=body)
    if r.status_code >= 300:
        raise HTTPException(r.status_code, f"AI provider error: {r.text}")
    data = r.json()
    text = ""
    for block in data.get("content", []):
        if block.get("type") == "text":
            text += block.get("text", "")
    return {"text": text}


# ────────────────────────────────────────────────────────────
# 2 · LEAD + PROSPECTUS STORAGE
# ────────────────────────────────────────────────────────────
class Lead(BaseModel):
    affiliate_code: str
    business_name: str
    industry: Optional[str] = ""
    contact_name: Optional[str] = ""
    phone: Optional[str] = ""
    email: Optional[str] = ""
    pain_point: Optional[str] = ""
    blueprint: Optional[str] = ""
    status: Optional[str] = "new"
    source: Optional[str] = "revvy"


@app.post("/api/leads")
async def save_lead(lead: Lead):
    """Save a prospect lead captured by Revvy to Supabase."""
    row = lead.dict()
    row["created_at"] = _now()
    result = await _supabase("POST", "revvy_leads", payload=row)
    return {"ok": True, "lead": result[0] if result else row}


@app.get("/api/leads")
async def list_leads(affiliate_code: str):
    """List all leads for one affiliate, newest first."""
    rows = await _supabase("GET", "revvy_leads", params={
        "affiliate_code": f"eq.{affiliate_code}",
        "order": "created_at.desc",
    })
    return {"ok": True, "leads": rows}


class Prospectus(BaseModel):
    affiliate_code: str
    business_name: str
    industry: Optional[str] = ""
    contact_name: Optional[str] = ""
    pain_point: Optional[str] = ""
    content: str


@app.post("/api/prospectuses")
async def save_prospectus(p: Prospectus):
    """Save a generated white-label prospectus."""
    row = p.dict()
    row["created_at"] = _now()
    result = await _supabase("POST", "revvy_prospectuses", payload=row)
    return {"ok": True, "prospectus": result[0] if result else row}


@app.get("/api/prospectuses")
async def list_prospectuses(affiliate_code: str):
    rows = await _supabase("GET", "revvy_prospectuses", params={
        "affiliate_code": f"eq.{affiliate_code}",
        "order": "created_at.desc",
    })
    return {"ok": True, "prospectuses": rows}


# ────────────────────────────────────────────────────────────
# 3 · TWILIO  — outbound voice + SMS
# ────────────────────────────────────────────────────────────
def _twiml_escape(s: str) -> str:
    return (s.replace("&", "&amp;").replace("<", "&lt;")
             .replace(">", "&gt;").replace('"', "&quot;"))


class SMSRequest(BaseModel):
    to: str                       # destination number, E.164 e.g. +1713...
    body: str
    affiliate_code: Optional[str] = ""


@app.post("/api/sms")
async def send_sms(req: SMSRequest):
    """Send an SMS via Twilio."""
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER):
        raise HTTPException(503, "Twilio is not configured on the server.")
    url = f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/Messages.json"
    data = {"To": req.to, "From": TWILIO_FROM_NUMBER, "Body": req.body}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(url, data=data,
                               auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN))
    if r.status_code >= 300:
        raise HTTPException(r.status_code, f"Twilio SMS error: {r.text}")
    # best-effort log
    try:
        await _supabase("POST", "revvy_calls", payload={
            "affiliate_code": req.affiliate_code, "direction": "outbound",
            "channel": "sms", "to_number": req.to, "body": req.body,
            "status": "sent", "created_at": _now(),
        })
    except Exception:
        pass
    return {"ok": True, "sid": r.json().get("sid", "")}


class CallRequest(BaseModel):
    to: str
    message: str                  # what Revvy should say when the call connects
    affiliate_code: Optional[str] = ""


@app.post("/api/call")
async def place_call(req: CallRequest):
    """Place an outbound voice call. Twilio fetches the script from /twiml below."""
    if not (TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER):
        raise HTTPException(503, "Twilio is not configured on the server.")
    import urllib.parse
    twiml_url = (f"{PUBLIC_BASE_URL}/api/twiml"
                 f"?message={urllib.parse.quote(req.message)}")
    url = f"https://api.twilio.com/2010-04-01/Accounts/{TWILIO_ACCOUNT_SID}/Calls.json"
    data = {"To": req.to, "From": TWILIO_FROM_NUMBER, "Url": twiml_url}
    async with httpx.AsyncClient(timeout=30) as client:
        r = await client.post(url, data=data,
                               auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN))
    if r.status_code >= 300:
        raise HTTPException(r.status_code, f"Twilio call error: {r.text}")
    try:
        await _supabase("POST", "revvy_calls", payload={
            "affiliate_code": req.affiliate_code, "direction": "outbound",
            "channel": "voice", "to_number": req.to, "body": req.message,
            "status": "initiated", "created_at": _now(),
        })
    except Exception:
        pass
    return {"ok": True, "sid": r.json().get("sid", "")}


@app.get("/api/twiml", response_class=PlainTextResponse)
async def twiml(message: str = "Hello from AgentAI888."):
    """Twilio fetches this to learn what to say on the call."""
    say = _twiml_escape(message)
    xml = (f'<?xml version="1.0" encoding="UTF-8"?>'
           f'<Response><Say voice="Polly.Joanna">{say}</Say>'
           f'<Pause length="1"/>'
           f'<Say voice="Polly.Joanna">Thank you. Goodbye.</Say></Response>')
    return PlainTextResponse(content=xml, media_type="application/xml")


# ────────────────────────────────────────────────────────────
# Health + config status
# ────────────────────────────────────────────────────────────
@app.get("/")
async def root():
    return {"service": "Revvy Backend", "status": "online"}


@app.get("/api/status")
async def status():
    """Lets the dashboard show which capabilities are live."""
    return {
        "ai":      bool(ANTHROPIC_API_KEY),
        "database": bool(SUPABASE_URL and SUPABASE_SERVICE_KEY),
        "twilio":  bool(TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN and TWILIO_FROM_NUMBER),
    }
